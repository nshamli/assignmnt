import React, {Component} from 'react';

class Box extends Component{
    selec='#eee';
constructor(props){
    super(props);
    this.state = {
      clicked:0,
      color:''
    };
    
    //this.handleClicked=this.handleClicked.bind(this);
    this.selected=this.selected.bind(this);
  }
//   handleClicked(){
//     this.setState({clicked:1, color:'red'});
//   }
  selected(event){
     
    if(document.getElementById("Red")&&document.getElementById("Red").checked)
    
    {this.selec= "Red";}
      if(document.getElementById("Blue")&&document.getElementById("Blue").checked)
    
    {this.selec= "Blue"; }
      if(document.getElementById("Green")&&document.getElementById("Green").checked)
    
    {this.selec= "Green";}
    
    if(event.target.style.backgroundColor==="red"||event.target.style.backgroundColor==="blue"||event.target.style.backgroundColor==="green"){
      alert('Already color applied');
      
    }
    else 
   {  event.target.style.backgroundColor=this.selec;
  }}

  
  render(){
   
    return(
        
        <div>
        <input type="radio" id="Red" name="color"    />Red
        <input type="radio" id="Blue" name="color"   />Blue
        <input type="radio" id="Green" name="color"  />Green
          
        <table>
        <div className="grid-container"  >
         
       <div className="grid-item" onClick={this.selected}  >1</div>
         <div className="grid-item"  onClick={this.selected} >2</div>
       <div className="grid-item" onClick={this.selected} >3</div>  
        <div className="grid-item"  onClick={this.selected} >4</div>
       <div className="grid-item" onClick={this.selected}>5</div>
      <div className="grid-item" onClick={this.selected}>6</div>  
         <div className="grid-item"  onClick={this.selected} >7</div>
       <div className="grid-item" onClick={this.selected} >8</div>
       <div className="grid-item" onClick={this.selected} >9</div>   
        
        
        

        </div>
        
      </table>
     </div>
    );
  }
}
export default Box;