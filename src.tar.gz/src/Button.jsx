import React, { Component } from 'react';
class Button extends Component{
    constructor(props){
        super(props);
        this.state={}
    }
    handleRequest(e){
        e.preventDefault();
        
    window.location.reload();
    }
    render(){
        return( 
            <button type="button" onClick={(e) => {this.handleRequest(e)}}>Reset</button>
        );
    }
}
export default Button;