import React, { Component } from 'react';
import Box from './Box';
import './Box.css';
import './App.css';
import Button from './Button';

class App extends Component {
  render() {
    return (
      <div>
        
        <Box/>
        <Button/>
        
</div>
    );
  }
}

export default App;
